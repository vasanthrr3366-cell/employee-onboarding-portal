import { useEffect, type ReactNode } from "react";
import { useRouter } from "@tanstack/react-router";
import { useApp, type Role } from "@/lib/app-context";

export function RoleGuard({ role, children }: { role: Role; children: ReactNode }) {
  const { state } = useApp();
  const router = useRouter();

  useEffect(() => {
    if (!state.session) router.navigate({ to: "/" });
    else if (state.session.role !== role) {
      const dest = state.session.role === "MAKER" ? "/maker" : state.session.role === "CHECKER" ? "/checker" : "/admin";
      router.navigate({ to: dest });
    }
  }, [state.session, role, router]);

  if (!state.session || state.session.role !== role) return null;
  return <>{children}</>;
}
