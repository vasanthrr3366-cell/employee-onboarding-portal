import { Link, useRouter } from "@tanstack/react-router";
import { useApp } from "@/lib/app-context";
import { LogOut } from "lucide-react";
import { toast } from "sonner";

interface NavItem {
  to: string;
  label: string;
}

export function Sidebar({ title, items }: { title: string; items: NavItem[] }) {
  const { state, dispatch } = useApp();
  const router = useRouter();

  const logout = () => {
    dispatch({ type: "LOGOUT" });
    toast.success("Logged out");
    router.navigate({ to: "/" });
  };

  return (
    <aside className="sticky top-0 flex h-screen w-64 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground">
      <div className="border-b border-sidebar-border px-6 py-5">
        <div className="text-xs uppercase tracking-wider text-sidebar-foreground/60">Onboarding Portal</div>
        <div className="mt-1 text-lg font-semibold">{title}</div>
      </div>
      <nav className="flex-1 space-y-1 px-3 py-4">
        {items.map((it) => (
          <Link
            key={it.to}
            to={it.to}
            activeProps={{ className: "bg-sidebar-accent text-sidebar-accent-foreground" }}
            className="block rounded-md px-3 py-2 text-sm font-medium hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
          >
            {it.label}
          </Link>
        ))}
      </nav>
      <div className="border-t border-sidebar-border p-4">
        {state.session && (
          <div className="mb-3 text-xs">
            <div className="font-medium">{state.session.name}</div>
            <div className="text-sidebar-foreground/60">{state.session.role}</div>
          </div>
        )}
        <button
          onClick={logout}
          className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm font-medium text-red-600 hover:bg-red-50"
        >
          <LogOut className="h-4 w-4" /> Logout
        </button>
      </div>
    </aside>
  );
}
