import type { Status } from "@/lib/app-context";

const map: Record<Status, string> = {
  DRAFT: "bg-gray-200 text-gray-800",
  PENDING_REVIEW: "bg-amber-100 text-amber-800 border border-amber-300",
  UNDER_REVIEW: "bg-blue-100 text-blue-800 border border-blue-300",
  APPROVED: "bg-green-100 text-green-800 border border-green-300",
  REJECTED: "bg-red-100 text-red-800 border border-red-300",
  SENT_BACK: "bg-orange-100 text-orange-800 border border-orange-300",
};

export function StatusBadge({ status }: { status: Status }) {
  return (
    <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${map[status]}`}>
      {status.replace("_", " ")}
    </span>
  );
}
