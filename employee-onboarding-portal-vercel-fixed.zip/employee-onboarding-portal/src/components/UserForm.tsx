import { useState } from "react";
import type { FormData } from "@/lib/app-context";
import { emptyForm } from "@/lib/app-context";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Eye, EyeOff } from "lucide-react";

interface Props {
  initial?: FormData;
  readOnly?: boolean;
  onAdd?: (data: FormData) => void;
  onReturn?: () => void;
  showPasswords?: boolean; // admin/checker may want eye toggle
  hideActions?: boolean;
}

const panOptions = [
  { v: "0", l: "0 - Mask Always" },
  { v: "1", l: "1 - View" },
  { v: "2", l: "2 - Print" },
];

const roleOptions = ["ROLE_TELLER", "ROLE_OFFICER", "ROLE_MANAGER", "ROLE_ADMIN"];
const profileOptions = ["PROFILE_A", "PROFILE_B", "PROFILE_C"];

export function UserForm({ initial, readOnly, onAdd, onReturn, showPasswords, hideActions }: Props) {
  const [data, setData] = useState<FormData>(initial ?? emptyForm);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showPwd, setShowPwd] = useState(showPasswords ?? false);

  const set = <K extends keyof FormData>(k: K, v: FormData[K]) => setData((d) => ({ ...d, [k]: v }));

  const validate = () => {
    const e: Record<string, string> = {};
    const required: (keyof FormData)[] = [
      "userId", "userName", "staffId", "password", "confirmPassword",
      "department", "designation", "email", "contactNumber",
      "userRoleId", "accountExpiryDate", "viewPan", "viewPanProfile", "printPan", "printPanProfile",
    ];
    required.forEach((k) => { if (!String(data[k]).trim()) e[k] = "Required"; });
    if (data.password && data.confirmPassword && data.password !== data.confirmPassword) e.confirmPassword = "Passwords do not match";
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) e.email = "Invalid email";
    if (data.accountExpiryDate && !/^\d{8}$/.test(data.accountExpiryDate)) e.accountExpiryDate = "Must be YYYYMMDD";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleAdd = () => {
    if (validate()) onAdd?.(data);
  };

  const field = (label: string, key: keyof FormData, required = false, type = "text") => (
    <div className="space-y-1.5">
      <Label htmlFor={key}>{label}{required && <span className="text-red-500"> *</span>}</Label>
      <Input
        id={key}
        type={type}
        value={String(data[key])}
        readOnly={readOnly}
        onChange={(e) => set(key, e.target.value as FormData[typeof key])}
        className={errors[key] ? "border-red-500" : ""}
      />
      {errors[key] && <p className="text-xs text-red-600">{errors[key]}</p>}
    </div>
  );

  const dropdown = (label: string, key: keyof FormData, options: { v: string; l: string }[], required = false, placeholder = "NO SELECT") => (
    <div className="space-y-1.5">
      <Label>{label}{required && <span className="text-red-500"> *</span>}</Label>
      <Select value={String(data[key])} onValueChange={(v) => set(key, v as FormData[typeof key])} disabled={readOnly}>
        <SelectTrigger className={errors[key] ? "border-red-500" : ""}><SelectValue placeholder={placeholder} /></SelectTrigger>
        <SelectContent>
          {options.map((o) => <SelectItem key={o.v} value={o.v}>{o.l}</SelectItem>)}
        </SelectContent>
      </Select>
      {errors[key] && <p className="text-xs text-red-600">{errors[key]}</p>}
    </div>
  );

  const pwdField = (label: string, key: keyof FormData, required = true) => (
    <div className="space-y-1.5">
      <Label>{label}{required && <span className="text-red-500"> *</span>}</Label>
      <div className="relative">
        <Input
          type={showPwd ? "text" : "password"}
          value={String(data[key])}
          readOnly={readOnly}
          onChange={(e) => set(key, e.target.value as FormData[typeof key])}
          className={errors[key] ? "border-red-500 pr-10" : "pr-10"}
        />
        <button type="button" onClick={() => setShowPwd((s) => !s)} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
          {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
      {errors[key] && <p className="text-xs text-red-600">{errors[key]}</p>}
    </div>
  );

  return (
    <div className="rounded-lg border bg-card p-6 shadow-sm">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {field("User ID", "userId", true)}
        {field("User Name", "userName", true)}
        {field("Staff ID", "staffId", true)}
        {pwdField("New Password", "password")}
        {pwdField("Confirm Password", "confirmPassword")}
        {field("Department", "department", true)}
        {field("Designation", "designation", true)}
        {field("Email", "email", true, "email")}
        {field("Contact Number", "contactNumber", true)}
        {dropdown("User Role ID", "userRoleId", roleOptions.map((r) => ({ v: r, l: r })), true)}
        <div className="space-y-1.5">
          <Label>Account Expiry Date<span className="text-red-500"> *</span></Label>
          <Input
            value={data.accountExpiryDate}
            readOnly={readOnly}
            onChange={(e) => set("accountExpiryDate", e.target.value)}
            placeholder="YYYYMMDD"
            className={errors.accountExpiryDate ? "border-red-500" : ""}
          />
          <p className="text-xs text-muted-foreground">Format: YYYYMMDD (default 99991231)</p>
          {errors.accountExpiryDate && <p className="text-xs text-red-600">{errors.accountExpiryDate}</p>}
        </div>
        {dropdown("View PAN", "viewPan", panOptions, true)}
        {dropdown("View PAN - Function Profile", "viewPanProfile", profileOptions.map((p) => ({ v: p, l: p })), true)}
        {dropdown("Print PAN", "printPan", panOptions, true)}
        {dropdown("Print PAN - Online Report Profile", "printPanProfile", profileOptions.map((p) => ({ v: p, l: p })), true)}
        {dropdown("Password Never Expires", "passwordNeverExpires", [{ v: "No", l: "No" }, { v: "Yes", l: "Yes" }])}
        <div className="space-y-1.5">
          <Label>Status</Label>
          <Input value={data.status} readOnly className="bg-muted" />
        </div>
        {dropdown("View Sensitive Data", "viewSensitiveData", [{ v: "No", l: "No" }, { v: "Yes", l: "Yes" }])}
        {dropdown("Maker Checker Group", "makerCheckerGroup",
          [{ v: "Not Applicable", l: "Not Applicable" }, { v: "Group A", l: "Group A" }, { v: "Group B", l: "Group B" }])}
      </div>

      {!hideActions && !readOnly && (
        <div className="mt-6 flex justify-end gap-3 border-t pt-4">
          <Button variant="outline" onClick={onReturn}>RETURN</Button>
          <Button onClick={handleAdd} className="bg-blue-600 hover:bg-blue-700">ADD</Button>
        </div>
      )}
    </div>
  );
}
