import { createContext, useContext, useEffect, useReducer, type ReactNode } from "react";

export type Role = "MAKER" | "CHECKER" | "ADMIN";
export type Status = "DRAFT" | "PENDING_REVIEW" | "UNDER_REVIEW" | "APPROVED" | "REJECTED" | "SENT_BACK";

export interface UserAccount {
  id: string;
  email: string;
  password: string;
  name: string;
  role: Role;
}

export interface FormData {
  userId: string;
  userName: string;
  staffId: string;
  password: string;
  confirmPassword: string;
  department: string;
  designation: string;
  email: string;
  contactNumber: string;
  userRoleId: string;
  accountExpiryDate: string;
  viewPan: string;
  viewPanProfile: string;
  printPan: string;
  printPanProfile: string;
  passwordNeverExpires: string;
  status: string;
  viewSensitiveData: string;
  makerCheckerGroup: string;
}

export interface OnboardingRequest {
  id: string;
  data: FormData;
  status: Status;
  makerId: string;
  makerName: string;
  checkerId?: string;
  checkerName?: string;
  comment?: string;
  rejectionReason?: string;
  sendBackReason?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  action: string;
  targetUserId: string;
  doneBy: string;
}

interface Session {
  userId: string;
  role: Role;
  name: string;
  token: string;
}

interface State {
  session: Session | null;
  users: UserAccount[];
  requests: OnboardingRequest[];
  audit: AuditEntry[];
}

type Action =
  | { type: "LOGIN"; session: Session }
  | { type: "LOGOUT" }
  | { type: "ADD_USER"; user: UserAccount }
  | { type: "UPDATE_USER_ROLE"; id: string; role: Role }
  | { type: "ADD_REQUEST"; request: OnboardingRequest }
  | { type: "UPDATE_REQUEST"; id: string; patch: Partial<OnboardingRequest> }
  | { type: "ADD_AUDIT"; entry: AuditEntry }
  | { type: "HYDRATE"; state: State };

const STORAGE_KEY = "onboarding_app_state_v1";

const seedUsers: UserAccount[] = [
  { id: "U001", email: "maker@bank.com", password: "maker123", name: "Alice Maker", role: "MAKER" },
  { id: "U002", email: "checker@bank.com", password: "checker123", name: "Bob Checker", role: "CHECKER" },
  { id: "U003", email: "admin@bank.com", password: "admin123", name: "Carol Admin", role: "ADMIN" },
];

const initial: State = {
  session: null,
  users: seedUsers,
  requests: [],
  audit: [],
};

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "HYDRATE":
      return action.state;
    case "LOGIN":
      return { ...state, session: action.session };
    case "LOGOUT":
      return { ...state, session: null };
    case "ADD_USER":
      return { ...state, users: [...state.users, action.user] };
    case "UPDATE_USER_ROLE":
      return { ...state, users: state.users.map((u) => (u.id === action.id ? { ...u, role: action.role } : u)) };
    case "ADD_REQUEST":
      return { ...state, requests: [action.request, ...state.requests] };
    case "UPDATE_REQUEST":
      return {
        ...state,
        requests: state.requests.map((r) =>
          r.id === action.id ? { ...r, ...action.patch, updatedAt: new Date().toISOString() } : r,
        ),
      };
    case "ADD_AUDIT":
      return { ...state, audit: [action.entry, ...state.audit] };
    default:
      return state;
  }
}

interface Ctx {
  state: State;
  dispatch: React.Dispatch<Action>;
  logAudit: (action: string, targetUserId: string) => void;
}

const AppContext = createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initial);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as State;
        // ensure seed users present
        const userIds = new Set(parsed.users.map((u) => u.id));
        seedUsers.forEach((u) => {
          if (!userIds.has(u.id)) parsed.users.push(u);
        });
        dispatch({ type: "HYDRATE", state: parsed });
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const logAudit = (action: string, targetUserId: string) => {
    if (!state.session) return;
    dispatch({
      type: "ADD_AUDIT",
      entry: {
        id: `A${Date.now()}`,
        timestamp: new Date().toISOString(),
        action,
        targetUserId,
        doneBy: state.session.name,
      },
    });
  };

  return <AppContext.Provider value={{ state, dispatch, logAudit }}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}

export const emptyForm: FormData = {
  userId: "",
  userName: "",
  staffId: "",
  password: "",
  confirmPassword: "",
  department: "",
  designation: "",
  email: "",
  contactNumber: "",
  userRoleId: "",
  accountExpiryDate: "99991231",
  viewPan: "",
  viewPanProfile: "",
  printPan: "",
  printPanProfile: "",
  passwordNeverExpires: "No",
  status: "ACTIVE",
  viewSensitiveData: "No",
  makerCheckerGroup: "Not Applicable",
};
