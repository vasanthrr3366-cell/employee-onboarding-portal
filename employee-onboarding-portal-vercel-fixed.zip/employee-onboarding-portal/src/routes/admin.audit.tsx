import { createFileRoute } from "@tanstack/react-router";
import { useApp } from "@/lib/app-context";

export const Route = createFileRoute("/admin/audit")({
  component: Audit,
});

function Audit() {
  const { state } = useApp();
  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">Audit Logs</h1>
      <div className="overflow-hidden rounded-lg border bg-card shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Timestamp</th>
              <th className="px-4 py-3">Action</th>
              <th className="px-4 py-3">Target User ID</th>
              <th className="px-4 py-3">Done By</th>
            </tr>
          </thead>
          <tbody>
            {state.audit.length === 0 && <tr><td colSpan={4} className="px-4 py-8 text-center text-muted-foreground">No audit entries yet.</td></tr>}
            {state.audit.map((a) => (
              <tr key={a.id} className="border-t">
                <td className="px-4 py-3 text-muted-foreground">{new Date(a.timestamp).toLocaleString()}</td>
                <td className="px-4 py-3 font-medium">{a.action}</td>
                <td className="px-4 py-3">{a.targetUserId}</td>
                <td className="px-4 py-3">{a.doneBy}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
