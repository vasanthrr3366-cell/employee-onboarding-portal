import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { useApp, type Role } from "@/lib/app-context";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/create")({
  component: CreateUser,
});

function CreateUser() {
  const { dispatch, logAudit, state } = useApp();
  const router = useRouter();
  const [id, setId] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<Role>("MAKER");
  const [show, setShow] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !name || !email || !password) return toast.error("All fields required");
    if (state.users.some((u) => u.id === id || u.email === email)) return toast.error("User ID or email already exists");
    dispatch({ type: "ADD_USER", user: { id, name, email, password, role } });
    logAudit(`USER_CREATED_AS_${role}`, id);
    toast.success("User created");
    router.navigate({ to: "/admin" });
  };

  return (
    <div className="max-w-xl">
      <h1 className="mb-6 text-2xl font-bold">Create User</h1>
      <form onSubmit={submit} className="space-y-4 rounded-lg border bg-card p-6 shadow-sm">
        <div className="space-y-1.5"><Label>User ID</Label><Input value={id} onChange={(e) => setId(e.target.value)} /></div>
        <div className="space-y-1.5"><Label>Name</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div className="space-y-1.5"><Label>Email</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div className="space-y-1.5">
          <Label>Password</Label>
          <div className="relative">
            <Input type={show ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} className="pr-10" />
            <button type="button" onClick={() => setShow((s) => !s)} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground">
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label>Assign Role</Label>
          <Select value={role} onValueChange={(v) => setRole(v as Role)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="MAKER">Maker</SelectItem>
              <SelectItem value="CHECKER">Checker</SelectItem>
              <SelectItem value="ADMIN">Admin</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex justify-end gap-3 border-t pt-4">
          <Button type="button" variant="outline" onClick={() => router.navigate({ to: "/admin" })}>Cancel</Button>
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700">Create User</Button>
        </div>
      </form>
    </div>
  );
}
