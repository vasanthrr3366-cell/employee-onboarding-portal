import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useApp, type Role } from "@/lib/app-context";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/")({
  component: AdminUsers,
});

function AdminUsers() {
  const { state, dispatch, logAudit } = useApp();
  const [showPwd, setShowPwd] = useState<Record<string, boolean>>({});

  const change = (id: string, role: Role) => {
    dispatch({ type: "UPDATE_USER_ROLE", id, role });
    logAudit(`ROLE_CHANGED_TO_${role}`, id);
    toast.success("Role updated");
  };

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">User Management</h1>
      <div className="overflow-hidden rounded-lg border bg-card shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-4 py-3">User ID</th>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Email</th>
              <th className="px-4 py-3">Password</th>
              <th className="px-4 py-3">Role</th>
            </tr>
          </thead>
          <tbody>
            {state.users.map((u) => (
              <tr key={u.id} className="border-t hover:bg-slate-50">
                <td className="px-4 py-3 font-medium">{u.id}</td>
                <td className="px-4 py-3">{u.name}</td>
                <td className="px-4 py-3">{u.email}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <span className="font-mono">{showPwd[u.id] ? u.password : "••••••••"}</span>
                    <button onClick={() => setShowPwd((s) => ({ ...s, [u.id]: !s[u.id] }))} className="text-muted-foreground hover:text-foreground">
                      {showPwd[u.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <Select value={u.role} onValueChange={(v) => change(u.id, v as Role)}>
                    <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MAKER">Maker</SelectItem>
                      <SelectItem value="CHECKER">Checker</SelectItem>
                      <SelectItem value="ADMIN">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
