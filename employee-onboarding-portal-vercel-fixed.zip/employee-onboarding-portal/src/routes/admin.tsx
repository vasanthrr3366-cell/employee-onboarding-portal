import { createFileRoute, Outlet } from "@tanstack/react-router";
import { RoleGuard } from "@/components/RoleGuard";
import { Sidebar } from "@/components/Sidebar";

export const Route = createFileRoute("/admin")({
  component: AdminLayout,
});

function AdminLayout() {
  return (
    <RoleGuard role="ADMIN">
      <div className="flex min-h-screen bg-slate-50">
        <Sidebar
          title="Admin Dashboard"
          items={[
            { to: "/admin", label: "Users" },
            { to: "/admin/create", label: "Create User" },
            { to: "/admin/audit", label: "Audit Logs" },
          ]}
        />
        <main className="flex-1 overflow-x-hidden p-8">
          <Outlet />
        </main>
      </div>
    </RoleGuard>
  );
}
