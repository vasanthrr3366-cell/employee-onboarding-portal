import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useApp, type Status } from "@/lib/app-context";
import { StatusBadge } from "@/components/StatusBadge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/checker/history")({
  component: History,
});

function History() {
  const { state } = useApp();
  const [filter, setFilter] = useState<"ALL" | Status>("ALL");
  const history = state.requests.filter((r) => ["APPROVED", "REJECTED", "SENT_BACK"].includes(r.status));
  const filtered = filter === "ALL" ? history : history.filter((r) => r.status === filter);

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Review History</h1>
        <Select value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
          <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All</SelectItem>
            <SelectItem value="APPROVED">Approved</SelectItem>
            <SelectItem value="REJECTED">Rejected</SelectItem>
            <SelectItem value="SENT_BACK">Sent Back</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="overflow-hidden rounded-lg border bg-card shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-4 py-3">User ID</th>
              <th className="px-4 py-3">User Name</th>
              <th className="px-4 py-3">Maker</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Reason / Comment</th>
              <th className="px-4 py-3">Updated</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">No records.</td></tr>}
            {filtered.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="px-4 py-3 font-medium">{r.data.userId}</td>
                <td className="px-4 py-3">{r.data.userName}</td>
                <td className="px-4 py-3">{r.makerName}</td>
                <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                <td className="px-4 py-3 text-muted-foreground">{r.rejectionReason || r.sendBackReason || r.comment || "—"}</td>
                <td className="px-4 py-3 text-muted-foreground">{new Date(r.updatedAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
