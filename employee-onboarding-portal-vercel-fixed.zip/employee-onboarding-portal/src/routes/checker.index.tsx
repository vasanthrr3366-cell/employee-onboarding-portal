import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useApp } from "@/lib/app-context";
import { StatusBadge } from "@/components/StatusBadge";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/checker/")({
  component: Pending,
});

function Pending() {
  const { state } = useApp();
  const [selected, setSelected] = useState<string | null>(null);
  const pending = state.requests.filter((r) => r.status === "PENDING_REVIEW" || r.status === "UNDER_REVIEW");

  return (
    <div>
      <h1 className="mb-1 text-2xl font-bold">Pending Review</h1>
      <p className="mb-6 text-muted-foreground">Select a request to review, then proceed.</p>

      <div className="overflow-hidden rounded-lg border bg-card shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="w-12 px-4 py-3">Select</th>
              <th className="px-4 py-3">User ID</th>
              <th className="px-4 py-3">User Name</th>
              <th className="px-4 py-3">Department</th>
              <th className="px-4 py-3">Maker</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Submitted</th>
            </tr>
          </thead>
          <tbody>
            {pending.length === 0 && (
              <tr><td colSpan={7} className="px-4 py-8 text-center text-muted-foreground">No requests pending.</td></tr>
            )}
            {pending.map((r) => (
              <tr key={r.id} className="border-t hover:bg-slate-50">
                <td className="px-4 py-3">
                  <Checkbox checked={selected === r.id} onCheckedChange={(v) => setSelected(v ? r.id : null)} />
                </td>
                <td className="px-4 py-3 font-medium">{r.data.userId}</td>
                <td className="px-4 py-3">{r.data.userName}</td>
                <td className="px-4 py-3">{r.data.department}</td>
                <td className="px-4 py-3">{r.makerName}</td>
                <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                <td className="px-4 py-3 text-muted-foreground">{new Date(r.updatedAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 flex justify-end">
        {selected ? (
          <Link to="/checker/review/$id" params={{ id: selected }}>
            <Button className="bg-blue-600 hover:bg-blue-700">Proceed to Review</Button>
          </Link>
        ) : (
          <Button disabled>Select a request to review</Button>
        )}
      </div>
    </div>
  );
}
