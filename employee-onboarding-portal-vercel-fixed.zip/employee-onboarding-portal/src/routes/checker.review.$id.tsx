import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useApp, type OnboardingRequest } from "@/lib/app-context";
import { UserForm } from "@/components/UserForm";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ConfirmModal } from "@/components/ConfirmModal";
import { toast } from "sonner";

export const Route = createFileRoute("/checker/review/$id")({
  component: Review,
});

function Review() {
  const { id } = Route.useParams();
  const { state, dispatch, logAudit } = useApp();
  const router = useRouter();
  const req = state.requests.find((r) => r.id === id);
  const [comment, setComment] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [approveOpen, setApproveOpen] = useState(false);
  const [rejectOpen, setRejectOpen] = useState(false);
  const [sendBackOpen, setSendBackOpen] = useState(false);

  useEffect(() => {
    if (req && req.status === "PENDING_REVIEW") {
      dispatch({ type: "UPDATE_REQUEST", id: req.id, patch: { status: "UNDER_REVIEW", checkerId: state.session?.userId, checkerName: state.session?.name } });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!req) return <div>Request not found.</div>;

  const finish = (status: "APPROVED" | "REJECTED" | "SENT_BACK", reason?: string) => {
    const patch: Partial<OnboardingRequest> = { status, comment };
    if (status === "REJECTED") patch.rejectionReason = reason;
    if (status === "SENT_BACK") patch.sendBackReason = reason;
    dispatch({ type: "UPDATE_REQUEST", id: req.id, patch });
    logAudit(status, req.data.userId);

    if (status === "APPROVED") {
      // create the actual user account
      dispatch({
        type: "ADD_USER",
        user: {
          id: req.data.userId,
          email: req.data.email,
          password: req.data.password,
          name: req.data.userName,
          role: "MAKER",
        },
      });
      toast.success("Approved — user account created");
    } else if (status === "REJECTED") toast.error("Request rejected");
    else toast.message("Sent back to maker");

    router.navigate({ to: "/checker" });
  };

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Review Request</h1>
          <div className="mt-1 flex items-center gap-3 text-sm text-muted-foreground">
            <StatusBadge status={req.status} />
            <span>By {req.makerName}</span>
          </div>
        </div>
        <Button variant="outline" onClick={() => router.navigate({ to: "/checker" })}>Back</Button>
      </div>

      <UserForm initial={req.data} readOnly hideActions showPasswords={false} />

      <div className="mt-6 rounded-lg border bg-card p-6 shadow-sm">
        <Label htmlFor="comment">Checker Comment</Label>
        <Textarea id="comment" rows={3} className="mt-2" placeholder="Optional comment..." value={comment} onChange={(e) => setComment(e.target.value)} />

        <div className="mt-4 flex items-center gap-2">
          <input id="confirm" type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} className="h-4 w-4" />
          <label htmlFor="confirm" className="text-sm">I have reviewed this request and confirm my decision</label>
        </div>

        <div className="mt-5 flex flex-wrap justify-end gap-3 border-t pt-4">
          <Button variant="outline" disabled={!confirmed} onClick={() => setSendBackOpen(true)} className="border-orange-400 text-orange-700 hover:bg-orange-50">Send Back</Button>
          <Button variant="destructive" disabled={!confirmed} onClick={() => setRejectOpen(true)}>Reject</Button>
          <Button disabled={!confirmed} onClick={() => setApproveOpen(true)} className="bg-green-600 hover:bg-green-700">Approve</Button>
        </div>
        {!confirmed && <p className="mt-2 text-right text-xs text-muted-foreground">Tick the confirmation checkbox to enable actions.</p>}
      </div>

      <ConfirmModal
        open={approveOpen}
        onOpenChange={setApproveOpen}
        title="Approve request?"
        description="The user account will be created upon approval."
        confirmLabel="Approve"
        onConfirm={() => finish("APPROVED")}
      />
      <ConfirmModal
        open={rejectOpen}
        onOpenChange={setRejectOpen}
        title="Reject request"
        description="Provide a reason for rejection."
        confirmLabel="Reject"
        variant="destructive"
        requireReason
        reasonLabel="Rejection reason"
        onConfirm={(r) => finish("REJECTED", r)}
      />
      <ConfirmModal
        open={sendBackOpen}
        onOpenChange={setSendBackOpen}
        title="Send back to maker"
        description="Provide a reason — the maker can revise and resubmit."
        confirmLabel="Send Back"
        requireReason
        reasonLabel="Reason to send back"
        onConfirm={(r) => finish("SENT_BACK", r)}
      />
    </div>
  );
}
