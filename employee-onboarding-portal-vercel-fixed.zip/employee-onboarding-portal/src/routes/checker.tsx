import { createFileRoute, Outlet } from "@tanstack/react-router";
import { RoleGuard } from "@/components/RoleGuard";
import { Sidebar } from "@/components/Sidebar";

export const Route = createFileRoute("/checker")({
  component: CheckerLayout,
});

function CheckerLayout() {
  return (
    <RoleGuard role="CHECKER">
      <div className="flex min-h-screen bg-slate-50">
        <Sidebar
          title="Checker Portal"
          items={[
            { to: "/checker", label: "Pending Review" },
            { to: "/checker/history", label: "History" },
          ]}
        />
        <main className="flex-1 overflow-x-hidden p-8">
          <Outlet />
        </main>
      </div>
    </RoleGuard>
  );
}
