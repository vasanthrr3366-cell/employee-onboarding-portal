import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { useApp, type Role } from "@/lib/app-context";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Login — Onboarding Portal" }] }),
  component: LoginPage,
});

function LoginPage() {
  const { state, dispatch } = useApp();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<Role>("MAKER");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = state.users.find((u) => u.email === email && u.password === password && u.role === role);
    if (!user) {
      toast.error("Invalid credentials or role mismatch");
      return;
    }
    dispatch({
      type: "LOGIN",
      session: { userId: user.id, role: user.role, name: user.name, token: `mock-jwt-${Date.now()}` },
    });
    toast.success(`Welcome, ${user.name}`);
    const dest = role === "MAKER" ? "/maker" : role === "CHECKER" ? "/checker" : "/admin";
    router.navigate({ to: dest });
  };

  const quick = (r: Role) => {
    const u = state.users.find((x) => x.role === r);
    if (u) { setEmail(u.email); setPassword(u.password); setRole(r); }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-50 to-slate-100 p-4">
      <div className="w-full max-w-md rounded-2xl border bg-card p-8 shadow-xl">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-blue-600 text-white font-bold">OP</div>
          <h1 className="text-2xl font-bold">Onboarding Portal</h1>
          <p className="text-sm text-muted-foreground">Sign in to continue</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <div className="space-y-1.5">
            <Label>Role</Label>
            <Select value={role} onValueChange={(v) => setRole(v as Role)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="MAKER">Maker</SelectItem>
                <SelectItem value="CHECKER">Checker</SelectItem>
                <SelectItem value="ADMIN">Admin</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">Sign in</Button>
        </form>

        <div className="mt-6 rounded-lg bg-slate-50 p-3 text-xs">
          <div className="mb-2 font-medium text-slate-700">Demo accounts:</div>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => quick("MAKER")} className="rounded bg-white px-2 py-1 shadow-sm hover:bg-blue-50">Maker</button>
            <button type="button" onClick={() => quick("CHECKER")} className="rounded bg-white px-2 py-1 shadow-sm hover:bg-blue-50">Checker</button>
            <button type="button" onClick={() => quick("ADMIN")} className="rounded bg-white px-2 py-1 shadow-sm hover:bg-blue-50">Admin</button>
          </div>
        </div>
      </div>
    </div>
  );
}
