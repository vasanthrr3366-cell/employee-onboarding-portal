import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { useApp, emptyForm, type FormData, type OnboardingRequest } from "@/lib/app-context";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { StatusBadge } from "@/components/StatusBadge";

export const Route = createFileRoute("/maker/bulk")({
  component: BulkUpload,
});

const HEADERS: (keyof FormData)[] = [
  "userId", "userName", "staffId", "password", "confirmPassword",
  "department", "designation", "email", "contactNumber",
  "userRoleId", "accountExpiryDate", "viewPan", "viewPanProfile",
  "printPan", "printPanProfile", "passwordNeverExpires",
  "viewSensitiveData", "makerCheckerGroup",
];

interface ParsedRow {
  row: number;
  data: FormData;
  errors: string[];
}

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let cur: string[] = [];
  let field = "";
  let inQ = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQ) {
      if (c === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (c === '"') inQ = false;
      else field += c;
    } else {
      if (c === '"') inQ = true;
      else if (c === ",") { cur.push(field); field = ""; }
      else if (c === "\n" || c === "\r") {
        if (c === "\r" && text[i + 1] === "\n") i++;
        cur.push(field); field = "";
        if (cur.some((v) => v.trim().length > 0)) rows.push(cur);
        cur = [];
      } else field += c;
    }
  }
  if (field.length || cur.length) { cur.push(field); if (cur.some((v) => v.trim().length > 0)) rows.push(cur); }
  return rows;
}

function validateRow(d: FormData): string[] {
  const errs: string[] = [];
  const req: (keyof FormData)[] = ["userId","userName","staffId","password","confirmPassword","department","designation","email","contactNumber","userRoleId","accountExpiryDate","viewPan","viewPanProfile","printPan","printPanProfile"];
  req.forEach((k) => { if (!String(d[k] ?? "").trim()) errs.push(`${k} required`); });
  if (d.password !== d.confirmPassword) errs.push("password mismatch");
  if (d.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) errs.push("invalid email");
  if (d.accountExpiryDate && !/^\d{8}$/.test(d.accountExpiryDate)) errs.push("expiry not YYYYMMDD");
  return errs;
}

function BulkUpload() {
  const { state, dispatch, logAudit } = useApp();
  const router = useRouter();
  const [rows, setRows] = useState<ParsedRow[]>([]);
  const [fileName, setFileName] = useState("");

  const downloadTemplate = () => {
    const sample = [
      HEADERS.join(","),
      "U100,John Doe,S100,Passw0rd!,Passw0rd!,Finance,Analyst,john@bank.com,9999999999,ROLE_OFFICER,99991231,1,PROFILE_A,0,PROFILE_A,No,No,Not Applicable",
      "U101,Jane Roe,S101,Passw0rd!,Passw0rd!,Ops,Manager,jane@bank.com,8888888888,ROLE_MANAGER,99991231,2,PROFILE_B,1,PROFILE_B,Yes,No,Group A",
    ].join("\n");
    const blob = new Blob([sample], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "employee_template.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  const handleFile = async (file: File) => {
    setFileName(file.name);
    const text = await file.text();
    const parsed = parseCsv(text);
    if (parsed.length < 2) { toast.error("CSV must include header + at least one row"); return; }
    const header = parsed[0].map((h) => h.trim());
    const missing = HEADERS.filter((h) => !header.includes(h));
    if (missing.length) { toast.error(`Missing columns: ${missing.join(", ")}`); return; }
    const idx = (k: string) => header.indexOf(k);

    const out: ParsedRow[] = parsed.slice(1).map((cols, i) => {
      const d: FormData = { ...emptyForm };
      HEADERS.forEach((k) => { d[k] = (cols[idx(k)] ?? "").trim(); });
      d.status = "ACTIVE";
      return { row: i + 2, data: d, errors: validateRow(d) };
    });
    setRows(out);
    toast.success(`Parsed ${out.length} rows`);
  };

  const importValid = () => {
    if (!state.session) return;
    const valid = rows.filter((r) => r.errors.length === 0);
    if (!valid.length) { toast.error("No valid rows to import"); return; }
    valid.forEach((r) => {
      const req: OnboardingRequest = {
        id: `R${Date.now()}${Math.floor(Math.random() * 1000)}`,
        data: r.data,
        status: "PENDING_REVIEW",
        makerId: state.session!.userId,
        makerName: state.session!.name,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      dispatch({ type: "ADD_REQUEST", request: req });
      logAudit("BULK_SUBMIT", r.data.userId);
    });
    toast.success(`Submitted ${valid.length} requests for review`);
    router.navigate({ to: "/maker/submissions" });
  };

  const validCount = rows.filter((r) => r.errors.length === 0).length;
  const errorCount = rows.length - validCount;

  return (
    <div>
      <h1 className="mb-1 text-2xl font-bold">Bulk Employee Upload</h1>
      <p className="mb-6 text-muted-foreground">Upload a CSV to create multiple onboarding requests at once.</p>

      <div className="mb-6 rounded-lg border bg-card p-6 shadow-sm">
        <div className="flex flex-wrap items-center gap-3">
          <Button variant="outline" onClick={downloadTemplate}>⬇ Download CSV Template</Button>
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
            Choose CSV file
            <input type="file" accept=".csv" className="hidden" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
          </label>
          {fileName && <span className="text-sm text-muted-foreground">{fileName}</span>}
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          Required columns: {HEADERS.join(", ")}
        </p>
      </div>

      {rows.length > 0 && (
        <>
          <div className="mb-4 flex items-center gap-4 text-sm">
            <span className="rounded-full bg-green-100 px-3 py-1 text-green-800">{validCount} valid</span>
            <span className="rounded-full bg-red-100 px-3 py-1 text-red-800">{errorCount} with errors</span>
            <div className="flex-1" />
            <Button disabled={!validCount} onClick={importValid} className="bg-blue-600 hover:bg-blue-700">
              Submit {validCount} valid → Pending Review
            </Button>
          </div>
          <div className="overflow-x-auto rounded-lg border bg-card shadow-sm">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-left text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-3 py-2">Row</th>
                  <th className="px-3 py-2">User ID</th>
                  <th className="px-3 py-2">Name</th>
                  <th className="px-3 py-2">Email</th>
                  <th className="px-3 py-2">Dept</th>
                  <th className="px-3 py-2">Status</th>
                  <th className="px-3 py-2">Issues</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.row} className={`border-t ${r.errors.length ? "bg-red-50/50" : ""}`}>
                    <td className="px-3 py-2">{r.row}</td>
                    <td className="px-3 py-2 font-medium">{r.data.userId}</td>
                    <td className="px-3 py-2">{r.data.userName}</td>
                    <td className="px-3 py-2">{r.data.email}</td>
                    <td className="px-3 py-2">{r.data.department}</td>
                    <td className="px-3 py-2">
                      {r.errors.length === 0 ? <StatusBadge status="PENDING_REVIEW" /> : <span className="text-red-600 text-xs font-medium">INVALID</span>}
                    </td>
                    <td className="px-3 py-2 text-xs text-red-700">{r.errors.join(", ")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
