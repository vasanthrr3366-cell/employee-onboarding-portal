import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useApp } from "@/lib/app-context";
import { UserForm } from "@/components/UserForm";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export const Route = createFileRoute("/maker/detail/$id")({
  component: Detail,
});

function Detail() {
  const { id } = Route.useParams();
  const { state, dispatch, logAudit } = useApp();
  const router = useRouter();
  const req = state.requests.find((r) => r.id === id);

  if (!req) return <div>Request not found.</div>;

  const submit = () => {
    dispatch({ type: "UPDATE_REQUEST", id: req.id, patch: { status: "PENDING_REVIEW" } });
    logAudit("SUBMIT_FOR_REVIEW", req.data.userId);
    toast.success("Submitted for checker review");
    router.navigate({ to: "/maker/submissions" });
  };

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Request {req.data.userId}</h1>
          <div className="mt-1 flex items-center gap-3 text-sm text-muted-foreground">
            <StatusBadge status={req.status} />
            <span>Created {new Date(req.createdAt).toLocaleString()}</span>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => router.navigate({ to: "/maker/submissions" })}>Back</Button>
          {(req.status === "DRAFT" || req.status === "SENT_BACK" || req.status === "REJECTED") && (
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={submit}>Submit for Review</Button>
          )}
        </div>
      </div>

      {(req.sendBackReason || req.rejectionReason || req.comment) && (
        <div className="mb-4 rounded-md border-l-4 border-amber-500 bg-amber-50 p-4 text-sm">
          {req.sendBackReason && <div><strong>Sent back:</strong> {req.sendBackReason}</div>}
          {req.rejectionReason && <div><strong>Rejected:</strong> {req.rejectionReason}</div>}
          {req.comment && <div><strong>Checker comment:</strong> {req.comment}</div>}
        </div>
      )}

      <UserForm initial={req.data} readOnly hideActions />
    </div>
  );
}
