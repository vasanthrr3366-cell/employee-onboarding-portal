import { createFileRoute, Link } from "@tanstack/react-router";
import { useApp } from "@/lib/app-context";

export const Route = createFileRoute("/maker/")({
  component: MakerHome,
});

function MakerHome() {
  const { state } = useApp();
  const mine = state.requests.filter((r) => r.makerId === state.session?.userId);
  const counts = {
    DRAFT: mine.filter((r) => r.status === "DRAFT").length,
    PENDING: mine.filter((r) => r.status === "PENDING_REVIEW" || r.status === "UNDER_REVIEW").length,
    APPROVED: mine.filter((r) => r.status === "APPROVED").length,
    REJECTED: mine.filter((r) => r.status === "REJECTED" || r.status === "SENT_BACK").length,
  };

  return (
    <div>
      <h1 className="mb-1 text-2xl font-bold">Welcome, {state.session?.name}</h1>
      <p className="mb-6 text-muted-foreground">Create and track user onboarding requests.</p>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {Object.entries(counts).map(([k, v]) => (
          <div key={k} className="rounded-lg border bg-card p-5 shadow-sm">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{k}</div>
            <div className="mt-1 text-3xl font-bold">{v}</div>
          </div>
        ))}
      </div>
      <div className="mt-6 flex gap-3">
        <Link to="/maker/new" className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">+ New Request</Link>
        <Link to="/maker/submissions" className="rounded-md border bg-white px-4 py-2 text-sm font-medium hover:bg-slate-50">View Submissions</Link>
      </div>
    </div>
  );
}
