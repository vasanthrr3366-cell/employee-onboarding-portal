import { createFileRoute, useRouter } from "@tanstack/react-router";
import { UserForm } from "@/components/UserForm";
import { useApp, type OnboardingRequest } from "@/lib/app-context";
import { toast } from "sonner";

export const Route = createFileRoute("/maker/new")({
  component: NewRequest,
});

function NewRequest() {
  const { state, dispatch, logAudit } = useApp();
  const router = useRouter();

  const handleAdd = (data: OnboardingRequest["data"]) => {
    if (!state.session) return;
    const req: OnboardingRequest = {
      id: `R${Date.now()}`,
      data,
      status: "DRAFT",
      makerId: state.session.userId,
      makerName: state.session.name,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setTimeout(() => {
      dispatch({ type: "ADD_REQUEST", request: req });
      logAudit("CREATE_DRAFT", data.userId);
      toast.success("Request saved as DRAFT");
      router.navigate({ to: "/maker/submissions" });
    }, 200);
  };

  return (
    <div>
      <h1 className="mb-1 text-2xl font-bold">New User ID Request</h1>
      <p className="mb-6 text-muted-foreground">Fill the form and click ADD to save as draft.</p>
      <UserForm onAdd={handleAdd} onReturn={() => router.navigate({ to: "/maker" })} />
    </div>
  );
}
