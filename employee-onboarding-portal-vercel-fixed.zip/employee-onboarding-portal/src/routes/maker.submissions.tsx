import { createFileRoute, Link } from "@tanstack/react-router";
import { useApp } from "@/lib/app-context";
import { StatusBadge } from "@/components/StatusBadge";

export const Route = createFileRoute("/maker/submissions")({
  component: Submissions,
});

function Submissions() {
  const { state } = useApp();
  const mine = state.requests.filter((r) => r.makerId === state.session?.userId);

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">My Submissions</h1>
      <div className="overflow-hidden rounded-lg border bg-card shadow-sm">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-4 py-3">User ID</th>
              <th className="px-4 py-3">User Name</th>
              <th className="px-4 py-3">Department</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Submitted</th>
              <th className="px-4 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {mine.length === 0 && (
              <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">No submissions yet.</td></tr>
            )}
            {mine.map((r) => (
              <tr key={r.id} className="border-t hover:bg-slate-50">
                <td className="px-4 py-3 font-medium">{r.data.userId}</td>
                <td className="px-4 py-3">{r.data.userName}</td>
                <td className="px-4 py-3">{r.data.department}</td>
                <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                <td className="px-4 py-3 text-muted-foreground">{new Date(r.createdAt).toLocaleString()}</td>
                <td className="px-4 py-3">
                  <Link to="/maker/detail/$id" params={{ id: r.id }} className="text-blue-600 hover:underline">View</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
