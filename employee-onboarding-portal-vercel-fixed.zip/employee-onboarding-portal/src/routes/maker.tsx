import { createFileRoute, Outlet } from "@tanstack/react-router";
import { RoleGuard } from "@/components/RoleGuard";
import { Sidebar } from "@/components/Sidebar";

export const Route = createFileRoute("/maker")({
  component: MakerLayout,
});

function MakerLayout() {
  return (
    <RoleGuard role="MAKER">
      <div className="flex min-h-screen bg-slate-50">
        <Sidebar
          title="Maker Portal"
          items={[
            { to: "/maker", label: "Dashboard" },
            { to: "/maker/new", label: "New Request" },
            { to: "/maker/bulk", label: "Bulk Upload (CSV)" },
            { to: "/maker/submissions", label: "My Submissions" },
          ]}
        />
        <main className="flex-1 overflow-x-hidden p-8">
          <Outlet />
        </main>
      </div>
    </RoleGuard>
  );
}
